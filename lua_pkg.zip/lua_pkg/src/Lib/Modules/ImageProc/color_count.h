#ifndef color_count_h_DEFINED
#define color_count_h_DEFINED

const int nColor = 256;

int *color_count(uint8_t *x, int n);
int *color_count_obs(uint8_t *x, int n);

#endif
