#ifndef lua_color_stats_h_DEFINED
#define lua_color_stats_h_DEFINED

int lua_color_stats(lua_State *L);
int lua_tilted_color_stats(lua_State *L);

#endif
