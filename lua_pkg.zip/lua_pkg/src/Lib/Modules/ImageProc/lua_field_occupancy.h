#ifndef lua_field_occupancy_h_DEFINED
#define lua_field_occupancy_h_DEFINED

int lua_field_occupancy(lua_State *L);

#endif
