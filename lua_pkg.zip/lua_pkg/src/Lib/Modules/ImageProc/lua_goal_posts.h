int lua_goal_posts(lua_State *L);
int lua_tilted_goal_posts(lua_State *L);
