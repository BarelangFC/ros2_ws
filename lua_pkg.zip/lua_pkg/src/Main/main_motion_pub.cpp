#include "rclcpp/rclcpp.hpp"
#include "example_interfaces/msg/string.hpp"


double  roll_,pitch_,yaw_ = 0;
int     strategy_cm_,kill_n_run_cm_ = 0;


class strategyNode : public rclcpp::Node
{
public:
    strategyNode() : Node("bfc_cpp_strategy")
    {
        publisher_ = this->create_publisher<example_interfaces::msg::String>("main_motion", 10);
        timer_ = this->create_wall_timer(std::chrono::milliseconds(50),
                                         std::bind(&strategyNode::publish, this));
        RCLCPP_INFO(this->get_logger(),"lua_motion_pub has been started.");

        subscriber_ = this -> create_subscription<example_interfaces::msg::String>(
            "imu_strategy",10,
            std::bind(&strategyNode::callBackSensor, this, std::placeholders::_1));
        RCLCPP_INFO(this -> get_logger(), "imu_strategy_sub has been started.");
    }

private:
    void publish()
    {
        auto msg = example_interfaces::msg::String();
        msg.data = &motion_state_pub_[0];
        publisher_ -> publish(msg);
        motion("0");
        Walk("0.00,0.00,0.00");
        headMove("1.00,2.00");
        set_motion_walk_head_move();
    }

    void callBackSensor(const example_interfaces::msg::String::SharedPtr msg)
    {
        RCLCPP_INFO(this->get_logger(), "%s", msg->data.c_str());
        hold_data_ = msg->data.c_str();
        parsing(hold_data_);
    }

    void parsing(std::string data_in_)
    {
        int countParse = 0;
        double	accrX, accrY, accrZ,
                gyroX, gyroY, gyroZ,
                angleX, angleY, angleZ,
                myAccrX, myAccrY = 0;
        int     strategyCM, killNrunCM = 0;
        char* str = &data_in_[0];
 
        // Returns first token
        char *token = strtok(str, ",");
    
        // Keep printing tokens while one of the
        // delimiters present in str[].
        while (token != NULL)
        {
            if (countParse == 0)	  { sscanf(token, "%lf", &accrX); } 
            else if (countParse == 1) { sscanf(token, "%lf", &accrY); }
            else if (countParse == 2) { sscanf(token, "%lf", &accrZ); } 
            else if (countParse == 3) { sscanf(token, "%lf", &gyroX); } 
            else if (countParse == 4) { sscanf(token, "%lf", &gyroY); } 
            else if (countParse == 5) { sscanf(token, "%lf", &gyroZ); } 
            else if (countParse == 6) { sscanf(token, "%lf", &angleX); } //roll
            else if (countParse == 7) { sscanf(token, "%lf", &angleY); } //pitch
            else if (countParse == 8) { sscanf(token, "%lf", &angleZ); } //yaw
            else if (countParse == 9) { sscanf(token, "%d", &strategyCM); } //strategy
            else if (countParse == 10) { sscanf(token, "%d", &killNrunCM); countParse = -1; } //killNrun
            // printf("%s\n", token);
            token = strtok(NULL, ",");
            countParse++;
        }   
        printf("  accr(%.2lf, %.2lf, %.2lf)", accrX, accrY, accrZ);
        printf("  gyro(%.2lf, %.2lf, %.2lf)", gyroX, gyroY, gyroZ);
        printf("  angle(%.2lf, %.2lf, %.2lf)", angleX, angleY, angleZ);
        printf("  strategy,killNrun(%d, %d)\n", strategyCM, killNrunCM);
	}

    void motion(std::string in_motion_)
    {
        set_motion_ = &in_motion_[0];
        // printf("motion %s\n", &set_motion_[0]);
    }

    void Walk(std::string in_walk_)
    {
        set_walk_ = std::string(",") + &in_walk_[0];
        // printf("walk %s\n", &set_walk_[0]);
    }

    void headMove(std::string in_head_move_)
    {
        set_head_move_ = std::string(",") + &in_head_move_[0];
    }

    void set_motion_walk_head_move() 
    {
        motion_state_pub_ = set_motion_ + set_walk_ + set_head_move_;
    }

    std::string motion_state_pub_,hold_data_,set_motion_,set_walk_,set_head_move_;
    rclcpp::Publisher<example_interfaces::msg::String>::SharedPtr publisher_;
    rclcpp::Subscription<example_interfaces::msg::String>::SharedPtr subscriber_;
    rclcpp::TimerBase::SharedPtr timer_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<strategyNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
