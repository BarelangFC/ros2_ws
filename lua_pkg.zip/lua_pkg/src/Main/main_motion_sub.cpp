#include "rclcpp/rclcpp.hpp"
#include "example_interfaces/msg/string.hpp"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>
#include <math.h>

#include <sys/socket.h>
#include <sys/time.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <string.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>

#define	PORT	3838
#define	BUFLEN	4096
#define BUFSIZE	1024

#define PORTM	5000	//motion
#define PORTH	5001	//head
#define HOST	"localhost"

bool    useSocket = true;
bool    robotFall = false;
double  erorrXwalk, erorrYwalk, erorrAwalk, headPan, headTilt, posPan, posTilt = 0.0; 


 //Socket LUA head&motion
int	sockmotion;
int	sockhead;
struct	sockaddr_in addrmotion;
struct	sockaddr_in addrhead;
struct	hostent *localserver;
char	dataMotion[20];
char	dataHead[20];
char	line[10];

class luaMotionNode : public rclcpp::Node 
{
public:
    luaMotionNode() : Node("bfc_lua_motion")
    {
        subscriber_ = this -> create_subscription<example_interfaces::msg::String>(
            "main_motion",10,
            std::bind(&luaMotionNode::callBackMotion, this, std::placeholders::_1));
        RCLCPP_INFO(this -> get_logger(), "lua_motion_sub has been started.");
    }

private:
    void callBackMotion(const example_interfaces::msg::String::SharedPtr msg)
    {
        RCLCPP_INFO(this->get_logger(), "%s", msg->data.c_str());
        hold_data_ = msg->data.c_str();
        parsing(hold_data_);
    }

    void parsing(std::string data_in_)
    {
        int countParse = 0;
        char* str = &data_in_[0];
 
        // Returns first token
        char *token = strtok(str, ",");
    
        // Keep printing tokens while one of the
        // delimiters present in str[].
        while (token != NULL)
        {
            if (countParse == 0)	  { sscanf(token, "%lf", &motion_state_sub_); }
            else if (countParse == 1) { sscanf(token, "%lf", &walk_x_); }
            else if (countParse == 2) { sscanf(token, "%lf", &walk_y_); }
            else if (countParse == 3) { sscanf(token, "%lf", &walk_a_); }
            else if (countParse == 4) { sscanf(token, "%lf", &head_pan_); }
            else if (countParse == 5) { sscanf(token, "%lf", &head_tilt_); countParse = -1; }
            // printf("%s\n", token);
            token = strtok(NULL, ",");
            countParse++;
        }
        printf("head %.2lf,%.2lf\n",head_pan_,head_tilt_);
        // send motion to lua
        std::string motion_state_;
        motion_state_ = std::to_string((int)motion_state_sub_);
        motion(&motion_state_[0]);
        //send walk to lua
        Walk(walk_x_,walk_y_,walk_a_);
        //send head movement to lua
        headMove(head_pan_,head_tilt_);
    }

    // Robot Movement ============================================================================
    void motion(char line[2]) {
        if (useSocket) { // Socket
            char awalan[50];
            strcpy(awalan, "motion");
            sprintf(dataMotion, "%s,%s",awalan, line);
            sendto(sockmotion, dataMotion, strlen(dataMotion), 0, (struct sockaddr *) &addrmotion, sizeof(addrmotion));
            printf("  data motion = %s,%s,%s\n", dataMotion,awalan,line);
        } else { // NotePad
            FILE *outputfp;
            outputfp = fopen("../Player/WalkNote", "wb");
            fprintf(outputfp, "%s", &line[0]);
            fclose(outputfp);
        }
    }

    // Walk Controller ===========================================================================
    double  walkX = 0.0,
            walkY = 0.0,
            walkA = 0.0;
    double Walk(double x, double y, double a) {

        char line[50];

        walkX = x;
        walkY = y;
        walkA = a;

        if (useSocket) { // Socket
            strcpy(line, "walk");
            sprintf(dataMotion, "%s,%.2f,%.2f,%.2f", line, x+erorrXwalk, y+erorrYwalk, a+erorrAwalk);
            sendto(sockmotion, dataMotion, strlen(dataMotion), 0,(struct sockaddr *) &addrmotion, sizeof(addrmotion));
            //printf("  data walk = %s\n", dataMotion);
        } else { // NotePad
            FILE *outputfp;
            strcpy(line, "walk");
            outputfp = fopen("../Player/WalkNote", "wb");
            fprintf(outputfp, "%s,%.2lf,%.2lf,%.2lf", &line[0], x+erorrXwalk, y, a);//setting jalan ditempat default
            fclose(outputfp);
            //printf("walk : %g,%g,%g\n",x,y,a);
        }
    }

        // Head Movement =============================================================================
    void headMove(double pan,double tilt) {
        if (useSocket) { // Socket
            if (robotFall) { sprintf(dataHead, "%.2f,%.2f", 0.0, -2.1); }
            else { sprintf(dataHead, "%.2f,%.2f", pan, tilt); }
            sendto(sockhead, dataHead, strlen(dataHead), 0,(struct sockaddr *) &addrhead, sizeof(addrhead));
            printf("  data head = %s\n", dataHead);
        } else { // NotePad
            FILE *fp, *outputfp;
            outputfp = fopen("../Player/HeadNote", "wb");
            fprintf(outputfp, "%.2lf,%.2lf", pan,tilt);
            fclose(outputfp);
        }

        headPan = posPan = pan;
        headTilt = posTilt = tilt;
        //printf("headPan = %.2f \t headTilt = %.2f\n", pan, tilt);
    }

    rclcpp::Subscription<example_interfaces::msg::String>::SharedPtr subscriber_;
    std::string hold_data_;
    double motion_state_sub_,walk_x_,walk_y_,walk_a_,head_pan_,head_tilt_;
};

///////////////////////////////////////////////////////////////////
///////////////////////open port LUA///////////////////////////////
///////////////////////////////////////////////////////////////////
void initSendDataMotion() {
    sockmotion = socket(AF_INET, SOCK_DGRAM, 0);
    localserver = gethostbyname(HOST);
    bzero((char *) &addrmotion, sizeof(addrmotion));
    addrmotion.sin_family = AF_INET;
    addrmotion.sin_port = htons(PORTM);
}

void initSendDataHead() {
    sockhead = socket(AF_INET, SOCK_DGRAM, 0);
    localserver = gethostbyname(HOST);
    bzero((char *) &addrhead, sizeof(addrhead));
    addrhead.sin_family = AF_INET;
    addrhead.sin_port = htons(PORTH);
}

int main(int argc, char **argv)
{
    initSendDataMotion();
    initSendDataHead();
    rclcpp::init(argc, argv);
    auto node = std::make_shared<luaMotionNode>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}