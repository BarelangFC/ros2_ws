require('Config');

GameControl = require(Config.dev.game_control)



