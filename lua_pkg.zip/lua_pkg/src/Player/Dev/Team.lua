require('Config');

Team = require(Config.dev.team)

