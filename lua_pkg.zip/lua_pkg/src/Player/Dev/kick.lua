require('Config');

kick = require(Config.dev.kick)

