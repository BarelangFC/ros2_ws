Camera = require "OPCam"

Camera.get_image();
Camera.stream_off();
Camera.stop();
