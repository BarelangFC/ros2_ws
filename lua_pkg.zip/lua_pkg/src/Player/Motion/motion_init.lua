require('Body');
require('motion');

print("DCM motion starting...");
motion.entry();
postProcess = motion.update;
