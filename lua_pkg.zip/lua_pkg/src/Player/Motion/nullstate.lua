module(..., package.seeall);

function entry()
end

function update()
end

function exit()
end
