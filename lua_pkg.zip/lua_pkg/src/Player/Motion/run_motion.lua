require('motion')
motion.entry()

while 1 do
  motion.update()
end
