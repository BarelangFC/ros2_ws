killall screen
screen -wipe
screen -S dcm
